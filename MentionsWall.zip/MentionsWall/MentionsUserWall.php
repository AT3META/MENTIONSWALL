<?php

function mentions_wall_init(){
        if(ossn_isLoggedin()) {             
                ossn_add_hook('wall', 'templates:item', 'mentions_tag_user_wall', 150);
        }
}
function mentions_tag_user_wall($hook, $type, $return, $params) {
        if(isset($return['text'])) {
                $return['text'] = mentions_replace_usernames($return['text']);
        }
        return $return;
}
ossn_register_callback('ossn', 'init', 'mentions_wall_init');

?>