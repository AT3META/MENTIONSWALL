<?php
 $en = array(
	'mention:post:created' => '%s mentioned you in a post!',
	'mention:comment:created' => '%s mentioned you in a comment!'		
);
ossn_register_languages('en', $en); 